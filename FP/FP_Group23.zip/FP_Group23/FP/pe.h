#ifndef PE_H
#define PE_H

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <iomanip>
#include <algorithm>
#include <vector>
#include <cmath>
#include "systemc.h"
using namespace std;

#define DEBUG_MODE false

struct Packet {
    int source_id;
    int dest_id;
    int packet_type;
    vector<float> datas;
    
    int height, width, channels;
};

class PE {
public:
    PE();
    Packet* get_packet();
    void check_packet(Packet* p);
    void init(int pe_id);

    bool is_ready_to_compute();
    void perform_computation();
    
private:
    int id;
    bool has_weights;
    bool has_bias;
    bool has_input;
    bool computation_done;

    vector<float> weights_vec;
    vector<float> bias_vec;
    vector<float> input_data_vec;
    vector<float> output_data_vec;

    int input_height, input_width, input_channels;


    void compute_conv1_maxpool1();    // PE_1
    void compute_conv2_maxpool2();    // PE_2  
    void compute_conv3();             // PE_3
    void compute_conv4();             // PE_7
    void compute_conv5_maxpool3();    // PE_6
    void compute_fc6();               // PE_5
    void compute_fc7();               // PE_4
    void compute_fc8();               // PE_12
    
 
    void convolution_2d(const vector<float>& input, vector<float>& output,
                       int in_h, int in_w, int in_ch, int out_ch,
                       int kernel_size, int stride, int padding, bool use_relu = true);
    void maxpooling_2d(const vector<float>& input, vector<float>& output,
                      int in_h, int in_w, int in_ch, 
                      int pool_size, int pool_stride);
    void fully_connected(const vector<float>& input, vector<float>& output,
                        int input_size, int output_size, bool use_relu = true);

    void compute_conv1_like_systemc(const vector<float>& input, vector<float>& output,
                                   int in_h, int in_w, int in_ch, int out_ch, 
                                   int out_h, int out_w, bool use_relu);
    void compute_conv2_like_systemc(const vector<float>& input, vector<float>& output,
                                   int in_h, int in_w, int in_ch, int out_ch, 
                                   int out_h, int out_w, bool use_relu);
    void compute_conv3_like_systemc(const vector<float>& input, vector<float>& output,
                                   int in_h, int in_w, int in_ch, int out_ch, 
                                   int out_h, int out_w, bool use_relu);
    void compute_conv4_like_systemc(const vector<float>& input, vector<float>& output,
                                   int in_h, int in_w, int in_ch, int out_ch, 
                                   int out_h, int out_w, bool use_relu);
    void compute_conv5_like_systemc(const vector<float>& input, vector<float>& output,
                                   int in_h, int in_w, int in_ch, int out_ch, 
                                   int out_h, int out_w, bool use_relu);

    void print_first_last_10(const vector<float>& data, const string& layer_name);
    void perform_input_padding();
    void print_layer_output();
    int get_next_pe_id();
    void get_output_dimensions(int& out_h, int& out_w, int& out_ch);
};

#endif