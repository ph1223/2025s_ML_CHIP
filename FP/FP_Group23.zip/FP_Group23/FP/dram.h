#ifndef DRAM_H
#define DRAM_H

#include "systemc.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
using namespace std;

// AXI Response types 
#define DRAM_AXI_RESP_OKAY   0x0
#define DRAM_AXI_RESP_EXOKAY 0x1
#define DRAM_AXI_RESP_SLVERR 0x2
#define DRAM_AXI_RESP_DECERR 0x3

// AXI Burst types 
#define DRAM_AXI_BURST_FIXED 0x0
#define DRAM_AXI_BURST_INCR  0x1
#define DRAM_AXI_BURST_WRAP  0x2

SC_MODULE(DRAM) {
    // Clock and Reset
    sc_in<bool> clk;
    sc_in<bool> rst;
    
    // AXI Read Address Channel
    sc_in<sc_lv<32> >   araddr;     // Read address
    sc_in<sc_lv<8> >    arlen;      // Burst length - 1 (0-255)
    sc_in<sc_lv<3> >    arsize;     // Transfer size (bytes = 2^arsize)
    sc_in<sc_lv<2> >    arburst;    // Burst type
    sc_in<bool>        arvalid;    // Address valid
    sc_out<bool>       arready;    // Address ready
    
    // AXI Read Data Channel  
    sc_out<sc_lv<32> >  rdata;      // Read data (32-bit for float)
    sc_out<sc_lv<2> >   rresp;      // Read response
    sc_out<bool>       rlast;      // Last transfer in burst
    sc_out<bool>       rvalid;     // Read data valid
    sc_in<bool>        rready;     // Read data ready
    
    // Internal memory and control
    vector<float> memory;           // Main memory storage
    
    // Address mapping constants
    static const int INPUT_DATA_SIZE = 150528;
    static const int CONV1_WEIGHT_SIZE = 23232;
    static const int CONV1_BIAS_SIZE = 64;
    static const int CONV2_WEIGHT_SIZE = 307200;
    static const int CONV2_BIAS_SIZE = 192;
    static const int CONV3_WEIGHT_SIZE = 663552;
    static const int CONV3_BIAS_SIZE = 384;
    static const int CONV4_WEIGHT_SIZE = 884736;
    static const int CONV4_BIAS_SIZE = 256;
    static const int CONV5_WEIGHT_SIZE = 589824;
    static const int CONV5_BIAS_SIZE = 256;
    static const int FC6_WEIGHT_SIZE = 37748736;
    static const int FC6_BIAS_SIZE = 4096;
    static const int FC7_WEIGHT_SIZE = 16777216;
    static const int FC7_BIAS_SIZE = 4096;
    static const int FC8_WEIGHT_SIZE = 4096000;
    static const int FC8_BIAS_SIZE = 1000;
    
    // Address mapping
    int INPUT_ADDR_BASE;
    int CONV1_WEIGHT_BASE;
    int CONV1_BIAS_BASE;
    int CONV2_WEIGHT_BASE;
    int CONV2_BIAS_BASE;
    int CONV3_WEIGHT_BASE;
    int CONV3_BIAS_BASE;
    int CONV4_WEIGHT_BASE;
    int CONV4_BIAS_BASE;
    int CONV5_WEIGHT_BASE;
    int CONV5_BIAS_BASE;
    int FC6_WEIGHT_BASE;
    int FC6_BIAS_BASE;
    int FC7_WEIGHT_BASE;
    int FC7_BIAS_BASE;
    int FC8_WEIGHT_BASE;
    int FC8_BIAS_BASE;
    
    // AXI transaction state
    enum axi_state_t {
        AXI_IDLE,
        AXI_READ_BURST
    };
    
    axi_state_t current_state;
    sc_lv<32> burst_addr;
    sc_lv<8>  burst_count;
    sc_lv<8>  burst_len;
    sc_lv<3>  burst_size;
    
    string DATA_PATH;
    string IMAGE_FILE_NAME;
    
    void axi_read_process();
    void load_all_data();
    void load_file_to_memory(const string& filename, int start_addr);
    int get_layer_base_address(int layer_id, bool is_bias);
    
    SC_CTOR(DRAM) {
        DATA_PATH = "./data/";
        
        const char* env_file = getenv("IMAGE_FILE_NAME");
        if (env_file != NULL) {
            IMAGE_FILE_NAME = env_file;
        } else {
            IMAGE_FILE_NAME = "cat.txt";
        }
        
        // Initialize address mapping
        setup_address_mapping();
        
        // Load all data into memory
        load_all_data();
        
        // Initialize AXI state
        current_state = AXI_IDLE;
        burst_count = "00000000";
        burst_len = "00000000";
        burst_addr = "00000000000000000000000000000000";
        burst_size = "000";
        
        SC_METHOD(axi_read_process);
        sensitive << clk.pos() << rst.neg();
        dont_initialize();
    }
    
private:
    void setup_address_mapping();
};

void DRAM::setup_address_mapping() {
    int addr = 0;
    
    INPUT_ADDR_BASE = addr;
    addr += INPUT_DATA_SIZE;
    
    CONV1_WEIGHT_BASE = addr;
    addr += CONV1_WEIGHT_SIZE;
    
    CONV1_BIAS_BASE = addr;
    addr += CONV1_BIAS_SIZE;
    
    CONV2_WEIGHT_BASE = addr;
    addr += CONV2_WEIGHT_SIZE;
    
    CONV2_BIAS_BASE = addr;
    addr += CONV2_BIAS_SIZE;
    
    CONV3_WEIGHT_BASE = addr;
    addr += CONV3_WEIGHT_SIZE;
    
    CONV3_BIAS_BASE = addr;
    addr += CONV3_BIAS_SIZE;
    
    CONV4_WEIGHT_BASE = addr;
    addr += CONV4_WEIGHT_SIZE;
    
    CONV4_BIAS_BASE = addr;
    addr += CONV4_BIAS_SIZE;
    
    CONV5_WEIGHT_BASE = addr;
    addr += CONV5_WEIGHT_SIZE;
    
    CONV5_BIAS_BASE = addr;
    addr += CONV5_BIAS_SIZE;
    
    FC6_WEIGHT_BASE = addr;
    addr += FC6_WEIGHT_SIZE;
    
    FC6_BIAS_BASE = addr;
    addr += FC6_BIAS_SIZE;
    
    FC7_WEIGHT_BASE = addr;
    addr += FC7_WEIGHT_SIZE;
    
    FC7_BIAS_BASE = addr;
    addr += FC7_BIAS_SIZE;
    
    FC8_WEIGHT_BASE = addr;
    addr += FC8_WEIGHT_SIZE;
    
    FC8_BIAS_BASE = addr;
    addr += FC8_BIAS_SIZE;
    
    // Reserve memory space
    memory.resize(addr, 0.0f);
    
    cout << "[DRAM] Total memory size: " << addr << " floats (" 
         << (addr * sizeof(float) / (1024*1024)) << " MB)" << endl;
}

void DRAM::load_all_data() {
    cout << "[DRAM] Loading all data into memory..." << endl;
    
    // Load input image data
    load_file_to_memory(DATA_PATH + IMAGE_FILE_NAME, INPUT_ADDR_BASE);
    
    // Load conv layers
    for (int layer = 1; layer <= 5; layer++) {
        stringstream ss;
        ss << layer;
        string weight_file = DATA_PATH + "conv" + ss.str() + "_weight.txt";
        string bias_file = DATA_PATH + "conv" + ss.str() + "_bias.txt";
        
        int weight_base = get_layer_base_address(layer, false);
        int bias_base = get_layer_base_address(layer, true);
        
        load_file_to_memory(weight_file, weight_base);
        load_file_to_memory(bias_file, bias_base);
    }
    
    // Load FC layers
    for (int layer = 6; layer <= 8; layer++) {
        stringstream ss;
        ss << layer;
        string weight_file = DATA_PATH + "fc" + ss.str() + "_weight.txt";
        string bias_file = DATA_PATH + "fc" + ss.str() + "_bias.txt";
        
        int weight_base = get_layer_base_address(layer, false);
        int bias_base = get_layer_base_address(layer, true);
        
        load_file_to_memory(weight_file, weight_base);
        load_file_to_memory(bias_file, bias_base);
    }
    
    cout << "[DRAM] All data loaded successfully!" << endl;//61251368 
    cout << "==================================================="<< endl;
     cout <<  "[DRAM] Last 5element"  << memory[61251365] << " " << memory[61251366] << " "<< memory[61251367] << endl;
   // cout <<  "[DRAM] Last element"  << memory[61251367] << endl;
     cout << "==================================================="<< endl;
}

void DRAM::load_file_to_memory(const string& filename, int start_addr) {
    ifstream file(filename.c_str());
    if (!file.is_open()) {
        cout << "[DRAM] Error: Cannot open file " << filename << endl;
        return;
    }
    
    float value;
    int addr = start_addr;
    int count = 0;
    
    while (file >> value && addr < memory.size()) {
        memory[addr] = value;
        addr++;
        count++;
    }
    
    file.close();
    //cout << "[DRAM] Loaded " << count << " values from " << filename 
    //     << " to address " << start_addr << endl;
}

int DRAM::get_layer_base_address(int layer_id, bool is_bias) {
    switch (layer_id) {
        case 0: return INPUT_ADDR_BASE;
        case 1: return is_bias ? CONV1_BIAS_BASE : CONV1_WEIGHT_BASE;
        case 2: return is_bias ? CONV2_BIAS_BASE : CONV2_WEIGHT_BASE;
        case 3: return is_bias ? CONV3_BIAS_BASE : CONV3_WEIGHT_BASE;
        case 4: return is_bias ? CONV4_BIAS_BASE : CONV4_WEIGHT_BASE;
        case 5: return is_bias ? CONV5_BIAS_BASE : CONV5_WEIGHT_BASE;
        case 6: return is_bias ? FC6_BIAS_BASE : FC6_WEIGHT_BASE;
        case 7: return is_bias ? FC7_BIAS_BASE : FC7_WEIGHT_BASE;
        case 8: return is_bias ? FC8_BIAS_BASE : FC8_WEIGHT_BASE;
        default:
            cout << "[DRAM] Error: Invalid layer_id " << layer_id << endl;
            return 0;
    }
}

void DRAM::axi_read_process() {
    if (rst.read()) {
        // Reset all AXI signals
        arready.write(false);
        rdata.write("00000000000000000000000000000000");
        rresp.write("00");  // DRAM_AXI_RESP_OKAY
        rlast.write(false);
        rvalid.write(false);
        
        current_state = AXI_IDLE;
        burst_count = "00000000";
        burst_len = "00000000";
        burst_addr = "00000000000000000000000000000000";
        return;
    }
    
    switch (current_state) {
        case AXI_IDLE:
            arready.write(true);
            rvalid.write(false);
            rlast.write(false);
            
            if (arvalid.read() && arready.read()) {
                // Accept address transaction
                burst_addr = araddr.read();
                burst_len = arlen.read();
                burst_size = arsize.read();
                burst_count = "00000000";
                
                arready.write(false);
                current_state = AXI_READ_BURST;
                
               // cout << "[DRAM] AXI Read transaction started: addr=0x" << hex << burst_addr.to_uint()
                //     << ", len=" << dec << (burst_len.to_uint() + 1) << " beats" << endl;
            }
            break;
            
        case AXI_READ_BURST:
            if (rready.read() || !rvalid.read()) {
                // Send next data beat
                unsigned int addr_offset = burst_addr.to_uint() + burst_count.to_uint();
                
                if (addr_offset < memory.size()) {
                    // Convert float to 32-bit representation
                    float data_val = memory[addr_offset];
                    union { float f; uint32_t i; } converter;
                    converter.f = data_val;
                    
                    sc_lv<32> data_lv;
                    for (int bit_idx = 0; bit_idx < 32; bit_idx++) {
                        bool bit_val = ((converter.i >> bit_idx) & 1) != 0;
                        data_lv[bit_idx] = bit_val;
                    }
                    rdata.write(data_lv);
                    rresp.write("00");  // DRAM_AXI_RESP_OKAY
                } else {
                    rdata.write("00000000000000000000000000000000");
                    rresp.write("10");  // DRAM_AXI_RESP_SLVERR
                    cout << "[DRAM] Error: Address out of bounds: " << addr_offset << endl;
                }
                
                rvalid.write(true);
                rlast.write(burst_count.to_uint() == burst_len.to_uint());
                
                if (burst_count.to_uint() == burst_len.to_uint()) {
                    current_state = AXI_IDLE;
                   // cout << "[DRAM] AXI Read burst completed" << endl;
                } else {
                    sc_lv<8> next_count = burst_count.to_uint() + 1;
                    burst_count = next_count;
                }
            }
            break;
    }
}

#endif