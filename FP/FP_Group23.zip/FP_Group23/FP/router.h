#ifndef ROUTER_H
#define ROUTER_H

#define FIFO_SIZE 400000
#define LEFT 0
#define RIGHT 1
#define UP 2
#define DOWN 3
#define CORE 4

#include <systemc.h>
#include <queue>
//#include <iostream> // removed unused include
// using namespace std; // removed to avoid cout usage

SC_MODULE(Router) {
    enum InputState { IDLE, ACCEPTING };
    enum OutputState { OUT_IDLE, OUT_REQ };

    sc_in<bool> rst;
    sc_in<bool> clk;

    sc_out<sc_lv<34> > out_flit[5];
    sc_out<bool> out_req[5];
    sc_in<bool> in_ack[5];

    sc_in<sc_lv<34> > in_flit[5];
    sc_in<bool> in_req[5];
    sc_out<bool> out_ack[5];

    int router_idx;
    int r_idx, c_idx;

    int dest_r[5], dest_c[5], diff_r[5], diff_c[5], dest_id[5], src_id[5], cur_dst[5];
    int dest_id_2[5], src_id_2[5];
    int dest_occupied_by[5];
    bool if_out_port_free[5];

    sc_lv<34> in_flit_temp[5];
    sc_lv<34> in_flit_temp_2[5];
    queue<sc_lv<34> > input_fifo[5];

    InputState input_state[5];
    OutputState output_state[5];

    void run();
    void reset();
    void fsm_inputs();
    void fsm_outputs();

    SC_HAS_PROCESS(Router);
    Router(sc_module_name name, int idx) : router_idx(idx) {
        SC_METHOD(run);
        sensitive << clk.pos();
        dont_initialize();
    }
};

void Router::reset() {
    r_idx = router_idx / 4;
    c_idx = router_idx % 4;
    for (int i = 0; i < 5; ++i) {
        input_state[i] = IDLE;
        output_state[i] = OUT_IDLE;
        if_out_port_free[i] = true;
        dest_occupied_by[i] = i;
        cur_dst[i] = i;
        dest_id[i] = router_idx;
        src_id[i] = router_idx;
        in_flit_temp[i] = 0;
        while (!input_fifo[i].empty()) input_fifo[i].pop();
        out_req[i].write(0);
        out_flit[i].write(0);
        out_ack[i].write(0);
    }
}

void Router::fsm_inputs() {
    for (int i = 0; i < 5; ++i) {
        switch (input_state[i]) {
            case IDLE:
                out_ack[i].write(0);
                if (in_req[i].read()) {
                   // cout << "[Router "<<router_idx<<"] Input "<<i<<": received request\n";
                    in_flit_temp[i] = in_flit[i].read();
                    //cout << "[Router "<<router_idx<<"] Input "<<i<<": received flit: " << in_flit_temp[i] << "\n";
                    // Header flit?
                    if (in_flit_temp[i][33] == '1') {
                        // Compute routing
                        dest_id[i] = in_flit_temp[i].range(27,24).to_uint();
                        src_id[i] = in_flit_temp[i].range(31,28).to_uint();

                        dest_r[i] = dest_id[i] / 4;
                        dest_c[i] = dest_id[i] % 4;

                        diff_r[i] = (4 + dest_r[i] - r_idx);
                        diff_c[i] = (4 + dest_c[i] - c_idx);

                        if (dest_c[i] != c_idx) {
                            cur_dst[i] = (dest_c[i] > c_idx) ? RIGHT : LEFT;
                        } else if (dest_r[i] != r_idx) {
                            cur_dst[i] = (dest_r[i] > r_idx) ? DOWN : UP;
                        } else {
                            cur_dst[i] = CORE;
                            if ((cur_dst[i] == CORE) && (dest_id[i] != router_idx)) {
                                cout << "MISMATCH error with dest_id and router_idx\n";
                            }
                        }
                        // Allocate output port
                        if (if_out_port_free[cur_dst[i]]) {
                            if_out_port_free[cur_dst[i]] = false;
                            dest_occupied_by[cur_dst[i]] = i;
                            input_fifo[i].push(in_flit_temp[i]);
                            out_ack[i].write(1);
                            input_state[i] = ACCEPTING;
                            cout << "[Router "<<router_idx<<"] Input "<<i<<": BOP captured, dst port = "<<cur_dst[i]<<" dst id = "<< dest_id[i] << " src id = "<< src_id[i]<<"\n";
                        }
                    }
                }
                break;

            case ACCEPTING:
                if (in_req[i].read() && input_fifo[i].size() < FIFO_SIZE) {
                    in_flit_temp[i] = in_flit[i].read();
                    input_fifo[i].push(in_flit_temp[i]);
                    out_ack[i].write(1);
                    // cout << "[Router "<<router_idx<<"] Input "<<i<<": Data/EOP captured\n";
                    // If it's tail flit (EOP), go back to IDLE
                    if (in_flit_temp[i][32] == '1') {
                        input_state[i] = IDLE;
                        cout << "==========================================" << endl;
                        cout << "[Router "<<router_idx<<"] Input "<<i<<": EOP, back to IDLE\n";
                        cout << "==========================================" << endl;
                        //cout <<"data " <<  in_flit_temp[i] << endl;
                    }
                } else {
                    out_ack[i].write(0);
                }
                break;
        }
    }
}

void Router::fsm_outputs() {
    for (int i = 0; i < 5; ++i) {
        int src = dest_occupied_by[i];
        // cout << "[Router "<<router_idx<<"] Output "<<i<<": src = "<< src << " cur_dst = "<< cur_dst[i] <<"\n";
        switch (output_state[i]) {
            case OUT_IDLE:
                out_req[i].write(0);
                out_flit[i].write(0);
                if (!if_out_port_free[i] && !input_fifo[src].empty()) {
                    out_flit[i].write(input_fifo[src].front());
                    out_req[i].write(1);

                    in_flit_temp_2[i] = input_fifo[src].front();
                    dest_id_2[i] = in_flit_temp_2[i].range(27,24).to_uint();
                    src_id_2[i] = in_flit_temp_2[i].range(31,28).to_uint();
                    output_state[i] = OUT_REQ;
                    // cout << "[Router "<< router_idx <<"] Output "<< i <<": send flit to port, dest id = "<< dest_id_2[i] << " src id = "<< src_id_2[i]<<"\n";
                }
                break;

            case OUT_REQ:
                if (out_req[i].read() && in_ack[i].read()) {
                    sc_lv<34> sent = input_fifo[src].front();
                    input_fifo[src].pop();
                    // cout << "[Router "<<router_idx<<"] Output "<<i<<": src = "<< src << " cur_dst = "<< cur_dst[i] <<"\n";
                    // cout << "[Router "<<router_idx<<"] Output "<<i<<": ACKed, flit popped, type="<< sent.range(33,32) <<"\n";
                    if (input_fifo[src].empty() || sent.range(33,32) == "01") {
                        if_out_port_free[i] = true;
                        out_req[i].write(0);
                        out_flit[i].write(0);
                        output_state[i] = OUT_IDLE;
                        // cout << "[Router "<<router_idx<<"] Output "<<i<<": released port\n";
                    } else {
                        out_flit[i].write(input_fifo[src].front());
                        out_req[i].write(1);
                        // cout << "[Router "<<router_idx<<"] Output "<<i<<": continue sending, next type="<< input_fifo[src].front().range(33,32) <<"\n";
                    }
                } else {
                    out_req[i].write(1);
                    out_flit[i].write(input_fifo[src].front());
   
                    // cout << "[Router "<<router_idx<<"] Output "<<i<<": waiting for ACK\n";
                }
                break;
        }
    }
}

void Router::run() {
    if (rst.read()) reset();
    else {
        fsm_inputs();
        fsm_outputs();
    }
}

#endif
