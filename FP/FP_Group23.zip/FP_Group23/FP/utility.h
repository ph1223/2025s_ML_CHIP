#define SC_INCLUDE_FX
#include <systemc.h>
#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include <cmath>
#include <algorithm>
#include <iomanip>
using namespace std;

#define IN_CH 3
#define IN_SIZE  224
#define IN_PAD 227
#define CONV1_CH_IN 3
#define CONV1_IN_SIZE 227
#define CONV1_STRIDE 4
#define CONV1_CH_OUT 64
#define CONV1_OUT_SIZE 55
#define CONV1_K_SIZE 11

#define MAXPOOLING_1_SIZE 3
#define MAXPOOLING_1_STRIDE 2
#define MAXPOOLING_1_OUT_SIZE 27
#define MAXPOOLING_CH_OUT 64

#define CONV2_CH_IN 64
#define CONV2_IN_SIZE 27
#define CONV2_CH_OUT 192
#define CONV2_STRIDE 1
#define CONV2_OUT_SIZE 27
#define CONV2_PADDING 2
#define CONV2_K_SIZE 5
#define MAXPOOLING_2_SIZE 3
#define MAXPOOLING_2_STRIDE 2
#define MAXPOOLING_2_OUT_SIZE 13
#define CONV3_CH_IN 192
#define CONV3_IN_SIZE 13
#define CONV3_CH_OUT 384
#define CONV3_OUT_SIZE 13
#define CONV3_PADDING 1
#define CONV3_K_SIZE 3
#define CONV3_STRIDE 1
#define CONV4_CH_IN 384
#define CONV4_CH_OUT 256
#define CONV4_IN_SIZE 13
#define CONV4_OUT_SIZE 13
#define CONV4_K_SIZE 3
#define CONV4_PADDING 1
#define CONV4_STRIDE 1
#define CONV5_CH_IN 256
#define CONV5_CH_OUT 256
#define CONV5_IN_SIZE 13
#define CONV5_K_SIZE 3
#define CONV5_OUT_SIZE 13
#define CONV5_PADDING 1
#define CONV5_STRIDE 1
#define MAXPOOLING_3_SIZE 3
#define MAXPOOLING_3_STRIDE 2
#define MAXPOOLING_3_OUT_SIZE 6
#define FC6_IN 9216
#define FC6_OUT 4096
#define FC7_IN 4096
#define FC7_OUT 4096
#define FC8_IN 4096
#define FC8_OUT 1000
#define INPUT_FEATURE_SIZE 150528

    void load_weights_and_biases(const string& layer_name, vector<double>& weights, 
        vector<double>& biases, int& weight_count, int& bias_count) {
        // cout << endl;
        // cout << "================ " << layer_name << " Weight and bias are loading =================" << endl;
        string weight_filename = "data/" + layer_name + "_weight.txt";
        string bias_filename = "data/" + layer_name + "_bias.txt";
        ifstream weight_file(weight_filename.c_str()); // Use .c_str() for compatibility
        ifstream bias_file(bias_filename.c_str());

        double element;
        weight_count = 0;
        bias_count = 0;

        weights.clear();
        while (weight_file >> element) {
            weights.push_back(element);
            weight_count++;
        }
        // cout << "================ Weight count: " << setw(6) << weight_count << " =================" << endl;

        biases.clear();
        while (bias_file >> element) {
            biases.push_back(element);
            bias_count++;
        }
        weight_file.close();
        bias_file.close();
        // cout << "================ Bias count:   " << setw(6) << bias_count << " =================" << endl;
        // cout << "First weight: " << setw(10) << weights[0] << "  Last weight: " << setw(10) << weights[weight_count-1] << endl;
        // cout << "First bias:   " << setw(10) << biases[0] << "  Last bias:   " << setw(10) << biases[bias_count-1] << endl; 
        // cout << "================ FINISH LOADING PARAMETER =================" << endl;
        // cout << endl;
    }

    //============================================================================================
    //
    //                       Method to load class name  
    //
    //============================================================================================
    vector<string> load_class_names() {
        vector<string> class_dict;
        string class_name = "data/imagenet_classes.txt";
        ifstream class_file(class_name.c_str()); // Use .c_str() for compatibility
        if (!class_file.is_open()) {
            cerr << "Error: Unable to open " << class_name << endl;
            return class_dict; // 返回空 vector
        }
    
        while (getline(class_file, class_name)) {
            class_dict.push_back(class_name);
        }
        class_file.close();
        //cout << "get class_names: " << class_dict.size() << endl;
        return class_dict;
    }


    struct ComparePair {
        bool operator()(const pair<double, int>& a, const pair<double, int>& b) {
            return a.first > b.first;
        }
    };
    void softmax_and_print_top5(vector<double>& out_feature, vector<string>& class_dict) {
        vector<pair<double, int> > indexed_values;
        vector<double> val;
        val.assign(1000, 0.0);
        double exp_sum = 0.0;
        
        for (int i = 0; i < 1000; i++) {
            val[i] = out_feature[i];
            out_feature[i] = exp(out_feature[i]);
            exp_sum += out_feature[i]; 
        }
        
        for (int i = 0; i < 1000; i++) {
            double softmax_value = (out_feature[i] / exp_sum) * 100.0; // Convert to percentage
            indexed_values.push_back(std::make_pair(softmax_value, i)); 
        }
        sort(indexed_values.begin(), indexed_values.end(), ComparePair());
        
        // Header setup
        cout << fixed << setprecision(2);
        cout << "Top 100 classes:" << endl;
        cout << "=================================================" << endl;

        cout <<  right << setw(5) << "idx" << " | " 
             << setw(8) << "val" << " | " 
             << setw(11) << "possibility" << " | " 
             << "class name" << endl;
        cout << "-------------------------------------------------" << endl;
        
        // Print top 5 results
        for (int i = 0; i < 100; i++) {
            int index = indexed_values[i].second;
            double softmax_value = indexed_values[i].first;
            
            cout << right << setw(5) << index << " | " 
                 << setw(8) << val[index] << " | " 
                 << setw(11) << softmax_value << " | " 
                 << class_dict[index] << endl;
        }
        cout << "=================================================" << endl;
    }