#ifndef CONTROLLER_AXI_H
#define CONTROLLER_AXI_H

#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <queue>
#include <string>
#include <cmath>
#include <sstream>
#include <algorithm>
using namespace std;
#include "systemc.h"

#define CTRL_AXI_BURST_LEN 255        // 16 beats per burst (0-15)
#define CTRL_AXI_SIZE_4BYTES 2       // 4 bytes = 2^2
#define CTRL_AXI_BURST_INCR 1        // Incremental burst

template<typename T>
string int_to_string(T value) {
    stringstream ss;
    ss << value;
    return ss.str();
}

bool compare_results(const std::pair<double, int>& a, const std::pair<double, int>& b) {
    return a.first > b.first;
}

enum ControllerState {
    RESET_STATE = 0,            
    IDLE_STATE = 1,            
    PARAM_LOAD = 2,           
    INPUT_LOAD = 3,             
    INFERENCE_WAIT = 4,       
    RESULT_COLLECT = 5,
    RESULT_PROCESS = 6 
};

enum AXILoadingPhase {
    AXI_PHASE_IDLE = 0,
    AXI_PHASE_ADDR = 1,         // Send address request
    AXI_PHASE_DATA = 2,         // Receive data bursts
    AXI_PHASE_SEND = 3,         // Send data to PEs
    AXI_PHASE_COMPLETE = 4      
};

struct ParameterTask {
    int layer_id;         
    bool is_bias;        
    int target_pe;         
    int expected_count;     
    int current_count;
    int base_address;       // Base address in DRAM
    string description;
    
    ParameterTask(int lid, bool bias, int pe, int count, int base_addr, const string& desc)
        : layer_id(lid), is_bias(bias), target_pe(pe), expected_count(count), 
          current_count(0), base_address(base_addr), description(desc) {}
};

SC_MODULE( Controller ) {
    sc_in  < bool >  rst;
    sc_in  < bool >  clk;
    
    // AXI Read Address Channel to DRAM
    sc_out<sc_lv<32> >   araddr;     
    sc_out<sc_lv<8> >    arlen;      
    sc_out<sc_lv<3> >    arsize;     
    sc_out<sc_lv<2> >    arburst;    
    sc_out<bool>        arvalid;    
    sc_in<bool>         arready;    
    
    // AXI Read Data Channel from DRAM  
    sc_in<sc_lv<32> >    rdata;      
    sc_in<sc_lv<2> >     rresp;      
    sc_in<bool>         rlast;      
    sc_in<bool>         rvalid;     
    sc_out<bool>        rready;     
    
    // to router0 (unchanged)
    sc_out < sc_lv<34> > flit_tx;
    sc_out < bool > req_tx;
    sc_in  < bool > ack_tx;

    // from router0 (unchanged)
    sc_in  < sc_lv<34> > flit_rx;
    sc_in  < bool > req_rx;
    sc_out < bool > ack_rx;

    //===========================================================================
    ControllerState current_state;
    ControllerState next_state;
    AXILoadingPhase param_phase;           
    AXILoadingPhase input_phase; 

    vector<ParameterTask> param_tasks;     
    int current_task_index;              
    bool all_params_loaded;              

    queue<sc_lv<34> > tx_fifo;            
    queue<float> axi_data_buffer;         // Buffer for AXI read data
    vector<float> fc8_results;           
    vector<string> class_names;

    // AXI transaction control
    sc_lv<32> current_addr;
    sc_lv<32> remaining_transfers;
    sc_lv<32> total_transfers;
    bool header_sent;                    
    bool transmission_active;            
    int flit_count;  
    int input_count;  

    //===========================================================================
    void fsm_update();
    void state_transition_logic();
    void axi_control_logic();
    void output_logic();

    // handle state
    void handle_reset_state();
    void handle_idle_state();
    void handle_param_load();          
    void handle_input_load();         
    void handle_inference_wait();
    void handle_result_collect();

    void process_param_axi_phase();
    void process_input_axi_phase();
    
    // tool 
    void initialize_param_tasks();
    void create_header_flit(int target_pe, bool is_bias);
    void create_data_flit(float data_val, bool is_last);
    sc_lv<32> float_to_lv(float f);
    float lv_to_float(sc_lv<32> lv);
    float lv32_to_float(sc_lv<32> lv);
    void log_debug(const string& msg);           
    void print_top100_results();
    int get_layer_base_address(int layer_id, bool is_bias);
    
    //===========================================================================
    SC_HAS_PROCESS(Controller);

    Controller(sc_module_name name) : sc_module(name) {
        current_state = RESET_STATE;
        next_state = RESET_STATE;
        
        current_task_index = 0;
        all_params_loaded = false;
        header_sent = false;
        transmission_active = false;
        flit_count = 0;
        input_count = 0;      
        current_addr = "00000000000000000000000000000000";
        remaining_transfers = "00000000000000000000000000000000";
        total_transfers = "00000000000000000000000000000000";
        
        initialize_param_tasks();
        
        SC_METHOD(fsm_update);
        sensitive << clk.pos();
        dont_initialize();

        SC_METHOD(axi_control_logic);
        sensitive << clk.pos();
        dont_initialize();        
    }
};

void Controller::initialize_param_tasks() {
    param_tasks.clear();
    
    // Calculate base addresses for each layer/type combination
    param_tasks.push_back(ParameterTask(1, false, 1, 23232, get_layer_base_address(1, false), "Conv1 weights to PE_1"));
    param_tasks.push_back(ParameterTask(1, true,  1, 64,    get_layer_base_address(1, true), "Conv1 bias to PE_1"));
    param_tasks.push_back(ParameterTask(2, false, 2, 307200, get_layer_base_address(2, false), "Conv2 weights to PE_2"));
    param_tasks.push_back(ParameterTask(2, true,  2, 192,   get_layer_base_address(2, true), "Conv2 bias to PE_2"));
    param_tasks.push_back(ParameterTask(3, false, 3, 663552, get_layer_base_address(3, false), "Conv3 weights to PE_3"));
    param_tasks.push_back(ParameterTask(3, true,  3, 384,   get_layer_base_address(3, true), "Conv3 bias to PE_3"));
    param_tasks.push_back(ParameterTask(4, false, 7, 884736, get_layer_base_address(4, false), "Conv4 weights to PE_7"));
    param_tasks.push_back(ParameterTask(4, true,  7, 256,   get_layer_base_address(4, true), "Conv4 bias to PE_7"));
    param_tasks.push_back(ParameterTask(5, false, 6, 589824, get_layer_base_address(5, false), "Conv5 weights to PE_6"));
    param_tasks.push_back(ParameterTask(5, true,  6, 256,   get_layer_base_address(5, true), "Conv5 bias to PE_6"));
    param_tasks.push_back(ParameterTask(6, false, 5, 37748736, get_layer_base_address(6, false), "FC6 weights to PE_5"));
    param_tasks.push_back(ParameterTask(6, true,  5, 4096,  get_layer_base_address(6, true), "FC6 bias to PE_5"));
    param_tasks.push_back(ParameterTask(7, false, 4, 16777216, get_layer_base_address(7, false), "FC7 weights to PE_4"));
    param_tasks.push_back(ParameterTask(7, true,  4, 4096,  get_layer_base_address(7, true), "FC7 bias to PE_4"));
    param_tasks.push_back(ParameterTask(8, false, 12, 4096000, get_layer_base_address(8, false), "FC8 weights to PE_12"));
    param_tasks.push_back(ParameterTask(8, true,  12, 1000,  get_layer_base_address(8, true), "FC8 bias to PE_12"));
}

int Controller::get_layer_base_address(int layer_id, bool is_bias) {
    // These should match the address mapping in DRAM.h
    const int INPUT_DATA_SIZE = 150528;
    const int CONV1_WEIGHT_SIZE = 23232;
    const int CONV1_BIAS_SIZE = 64;
    const int CONV2_WEIGHT_SIZE = 307200;
    const int CONV2_BIAS_SIZE = 192;
    const int CONV3_WEIGHT_SIZE = 663552;
    const int CONV3_BIAS_SIZE = 384;
    const int CONV4_WEIGHT_SIZE = 884736;
    const int CONV4_BIAS_SIZE = 256;
    const int CONV5_WEIGHT_SIZE = 589824;
    const int CONV5_BIAS_SIZE = 256;
    const int FC6_WEIGHT_SIZE = 37748736;
    const int FC6_BIAS_SIZE = 4096;
    const int FC7_WEIGHT_SIZE = 16777216;
    const int FC7_BIAS_SIZE = 4096;
    const int FC8_WEIGHT_SIZE = 4096000;
    int addr = 0;
    
    // Input data base
    if (layer_id == 0) return addr;
    addr += INPUT_DATA_SIZE;
    
    // Conv1
    if (layer_id == 1 && !is_bias) return addr;
    addr += CONV1_WEIGHT_SIZE;
    if (layer_id == 1 && is_bias) return addr;
    addr += CONV1_BIAS_SIZE;
    
    // Conv2
    if (layer_id == 2 && !is_bias) return addr;
    addr += CONV2_WEIGHT_SIZE;
    if (layer_id == 2 && is_bias) return addr;
    addr += CONV2_BIAS_SIZE;
    
    // Conv3
    if (layer_id == 3 && !is_bias) return addr;
    addr += CONV3_WEIGHT_SIZE;
    if (layer_id == 3 && is_bias) return addr;
    addr += CONV3_BIAS_SIZE;
    
    // Conv4
    if (layer_id == 4 && !is_bias) return addr;
    addr += CONV4_WEIGHT_SIZE;
    if (layer_id == 4 && is_bias) return addr;
    addr += CONV4_BIAS_SIZE;
    
    // Conv5
    if (layer_id == 5 && !is_bias) return addr;
    addr += CONV5_WEIGHT_SIZE;
    if (layer_id == 5 && is_bias) return addr;
    addr += CONV5_BIAS_SIZE;
    
    // FC6
    if (layer_id == 6 && !is_bias) return addr;
    addr += FC6_WEIGHT_SIZE;
    if (layer_id == 6 && is_bias) return addr;
    addr += FC6_BIAS_SIZE;
    
    // FC7
    if (layer_id == 7 && !is_bias) return addr;
    addr += FC7_WEIGHT_SIZE;
    if (layer_id == 7 && is_bias) return addr;
    addr += FC7_BIAS_SIZE;
    
    // FC8
    if (layer_id == 8 && !is_bias) return addr; 
    addr += FC8_WEIGHT_SIZE;  
    if (layer_id == 8 && is_bias) return addr;  
    // FC8 bias address would be addr + FC8_WEIGHT_SIZE
    
    return addr;
}

void Controller::fsm_update() {
    if (rst.read()) {
        current_state = RESET_STATE;
        next_state = RESET_STATE;
        return;
    }
    
    state_transition_logic();
    
    if (next_state != current_state) {
        current_state = next_state;
        if (current_state == PARAM_LOAD) {
            param_phase = AXI_PHASE_IDLE;
        } else if (current_state == INPUT_LOAD) {
            input_phase = AXI_PHASE_IDLE;
            input_count = 0;
        }
    } 

    output_logic();
}

void Controller::state_transition_logic() {
    next_state = current_state;
    switch (current_state) {
        case RESET_STATE:
            handle_reset_state();
            break;
        case IDLE_STATE:
            handle_idle_state();
            break;
        case PARAM_LOAD:
            handle_param_load();
            break;
        case INPUT_LOAD:
            handle_input_load();
            break;
        case INFERENCE_WAIT:
            handle_inference_wait();
            break;
        case RESULT_COLLECT:
            handle_result_collect();
            break;
        case RESULT_PROCESS:
            print_top100_results();
            exit(0);
            next_state = IDLE_STATE;
            break;
        default:
            next_state = current_state; 
            break;
    }
}

void Controller::handle_reset_state() {
    current_task_index = 0;
    all_params_loaded = false;
    header_sent = false;
    transmission_active = false;
    flit_count = 0;
    
    param_phase = AXI_PHASE_IDLE;
    input_phase = AXI_PHASE_IDLE;
    
    while (!tx_fifo.empty()) tx_fifo.pop();
    while (!axi_data_buffer.empty()) axi_data_buffer.pop();
    fc8_results.clear();
    
    current_addr = "00000000000000000000000000000000";
    remaining_transfers = "00000000000000000000000000000000";
    total_transfers = "00000000000000000000000000000000";
    
    class_names.clear();
    ifstream file("data/imagenet_classes.txt");
    if (!file.is_open()) {
        log_debug("Warning: Could not open imagenet_classes.txt");
    } else {
        string class_name;
        while (getline(file, class_name) && class_names.size() < 1000) {
            class_names.push_back(class_name);
        }
        file.close();
        log_debug("Reset completed, loaded " + int_to_string(class_names.size()) + " class names");
    }
    next_state = IDLE_STATE;
}

void Controller::handle_idle_state() {
    if (current_task_index < param_tasks.size()) {
        next_state = PARAM_LOAD;
        log_debug("Starting parameter loading for task " + int_to_string(current_task_index));
    }
    else if (!all_params_loaded) {
        all_params_loaded = true;
        next_state = INPUT_LOAD;
        log_debug("All parameters loaded, starting input loading");
    }
    else {
        next_state = INFERENCE_WAIT;
        log_debug("Entering inference wait state");
    }
}

void Controller::handle_param_load() {
    process_param_axi_phase();
    
    if (param_phase == AXI_PHASE_COMPLETE) {
        current_task_index++;
        log_debug("Parameter task " + int_to_string(current_task_index - 1) + " completed");
        
        if (current_task_index < param_tasks.size()) {
            param_phase = AXI_PHASE_IDLE;
            log_debug("Starting next parameter task " + int_to_string(current_task_index));
        } else {
            next_state = IDLE_STATE;
            log_debug("All parameter tasks completed");
        }
    }
}

void Controller::handle_input_load() {
    process_input_axi_phase();
    
    if (input_phase == AXI_PHASE_COMPLETE) {
        next_state = IDLE_STATE;
        log_debug("Input loading completed");
    }
}

void Controller::handle_inference_wait() {
    if (req_rx.read()) {
        next_state = RESULT_COLLECT;
        log_debug("Started receiving inference results");
    }
}

void Controller::handle_result_collect() {
    if (fc8_results.size() >= 1000) {
        next_state = RESULT_PROCESS;
        log_debug("Collected " + int_to_string(fc8_results.size()) + " results");
    }
    
    if (!req_rx.read() && fc8_results.size() > 0 && fc8_results.size() < 1000) {
        cout << "ERROR: Inference result collection incomplete, only " 
             << fc8_results.size() << " results collected" << endl;
        next_state = IDLE_STATE;
    }
}

void Controller::process_param_axi_phase() {
    ParameterTask& task = param_tasks[current_task_index];
    
    switch (param_phase) {
        case AXI_PHASE_IDLE:
            log_debug("Starting AXI read for " + task.description);
            current_addr = task.base_address;
            remaining_transfers = task.expected_count;
            total_transfers = task.expected_count;
            task.current_count = 0;
            create_header_flit(task.target_pe, task.is_bias);
            param_phase = AXI_PHASE_ADDR;
            break;
            
        case AXI_PHASE_ADDR:
            // Address phase handled in axi_control_logic
            break;
            
        case AXI_PHASE_DATA:
            // Data phase handled in axi_control_logic
            if (remaining_transfers.to_uint() == 0) {
                param_phase = AXI_PHASE_SEND;
                log_debug("AXI read completed for " + task.description);
            }
            break;
            
        case AXI_PHASE_SEND:
            if (tx_fifo.empty()) {
                param_phase = AXI_PHASE_COMPLETE;
                log_debug("Parameter transmission completed for " + task.description);
            }
            break;
            
        case AXI_PHASE_COMPLETE:
            break;
    }
}

void Controller::process_input_axi_phase() {
    switch (input_phase) {
        case AXI_PHASE_IDLE:
            {
                log_debug("Starting AXI read for input image data");
                current_addr = get_layer_base_address(0, false); // Input data base address
                remaining_transfers = 150528; // INPUT_DATA_SIZE
                total_transfers = 150528;
                input_count = 0;
                
                sc_lv<34> header_flit = 0;
                header_flit.range(33, 32) = "10";
                header_flit.range(27, 24) = 1;
                header_flit.range(23, 22) = "00";
                header_flit.range(21, 18) = 1;
                tx_fifo.push(header_flit);
                
                input_phase = AXI_PHASE_ADDR;
            }
            break;
            
        case AXI_PHASE_ADDR:
            // Address phase handled in axi_control_logic
            break;
            
        case AXI_PHASE_DATA:
            // Data phase handled in axi_control_logic
            if (remaining_transfers.to_uint() == 0) {
                input_phase = AXI_PHASE_SEND;
                log_debug("Input AXI read completed, total pixels: " + int_to_string(input_count));
            }
            break;
            
        case AXI_PHASE_SEND:
            if (tx_fifo.empty()) {
                input_phase = AXI_PHASE_COMPLETE;
                log_debug("Input transmission completed");
            }
            break;
            
        case AXI_PHASE_COMPLETE:
            break;
    }
}

void Controller::axi_control_logic() {
    if (rst.read()) {
        arvalid.write(false);
        rready.write(false);
        while (!axi_data_buffer.empty()) axi_data_buffer.pop();
        return;
    }
    
    // Handle address phase
    if ((param_phase == AXI_PHASE_ADDR || input_phase == AXI_PHASE_ADDR) && !arvalid.read()) {
        // Calculate burst parameters
        unsigned int remaining = remaining_transfers.to_uint();
        unsigned int burst_transfers = (remaining < (CTRL_AXI_BURST_LEN + 1)) ? remaining : (CTRL_AXI_BURST_LEN + 1);
        
        araddr.write(current_addr);
        
        sc_lv<8> arlen_val = burst_transfers - 1;  // AXI burst length is N-1
        arlen.write(arlen_val);
        
        arsize.write("010");  // CTRL_AXI_SIZE_4BYTES = 2
        arburst.write("01");  // CTRL_AXI_BURST_INCR = 1
        arvalid.write(true);
        
        // log_debug("AXI Address: 0x" + int_to_string(current_addr.to_uint()) + 
        //          ", burst_len=" + int_to_string(burst_transfers));
    }
    
    if (arvalid.read() && arready.read()) {
        arvalid.write(false);
        if (param_phase == AXI_PHASE_ADDR) {
            param_phase = AXI_PHASE_DATA;
        } else if (input_phase == AXI_PHASE_ADDR) {
            input_phase = AXI_PHASE_DATA;
        }
    }
    
    // Handle data phase
    if (param_phase == AXI_PHASE_DATA || input_phase == AXI_PHASE_DATA) {
        rready.write(true);
        
        if (rvalid.read() && rready.read()) {
            float data_val = lv32_to_float(rdata.read());
            axi_data_buffer.push(data_val);
            
            if (param_phase == AXI_PHASE_DATA) {
                ParameterTask& task = param_tasks[current_task_index];
                task.current_count++;
                bool is_last = (task.current_count >= task.expected_count);
                create_data_flit(data_val, is_last);
                
                if (task.current_count % 100000 == 0) {
                    log_debug("Received " + int_to_string(task.current_count) + 
                             "/" + int_to_string(task.expected_count) + " parameters");
                }
            } else {
                input_count++;
                bool is_last = (input_count >= 150528);
                create_data_flit(data_val, is_last);
                
                if (input_count % 10000 == 0) {
                    log_debug("Received " + int_to_string(input_count) + " input pixels");
                }
            }
            
            unsigned int remaining = remaining_transfers.to_uint();
            remaining_transfers = remaining - 1;
            
            unsigned int curr_addr = current_addr.to_uint();
            current_addr = curr_addr + 1;
            
            if (rlast.read()) {
                // End of current burst
                if (remaining_transfers.to_uint() > 0) {
                    // Need more bursts
                    if (param_phase == AXI_PHASE_DATA) {
                        param_phase = AXI_PHASE_ADDR;
                    } else if (input_phase == AXI_PHASE_DATA) {
                        input_phase = AXI_PHASE_ADDR;
                    }
                }
            }
        }
    } else {
        rready.write(false);
    }
    
    // Handle transmission of data to PEs
    if (ack_tx.read() && req_tx.read() && !tx_fifo.empty()) {
        tx_fifo.pop();
        flit_count++;
    }
    
    // Handle result collection
    if (req_rx.read() && ack_rx.read()) {
        sc_lv<34> rx_flit = flit_rx.read();
        if (rx_flit[33] != 1) {
            fc8_results.push_back(lv_to_float(rx_flit.range(31, 0)));
        }
    }
}

void Controller::output_logic() {
    // AXI signals controlled by axi_control_logic
    req_tx.write(false);
    flit_tx.write(0);
    ack_rx.write(false);
    
    switch (current_state) {
        case PARAM_LOAD:
            if (param_phase == AXI_PHASE_SEND && !tx_fifo.empty()) {
                req_tx.write(true);
                flit_tx.write(tx_fifo.front());
            }
            break;
            
        case INPUT_LOAD:
            if (input_phase == AXI_PHASE_SEND && !tx_fifo.empty()) {
                req_tx.write(true);
                flit_tx.write(tx_fifo.front());
            }
            break;
            
        case RESULT_COLLECT:
            if (req_rx.read()) {
                ack_rx.write(true);
            }
            break;
            
        default:
            break;
    }
}

void Controller::create_header_flit(int target_pe, bool is_bias) {
    sc_lv<34> header_flit = 0;
    header_flit.range(33, 32) = "10";
    header_flit.range(31, 28) = "0000";
    header_flit.range(27, 24) = target_pe;
    header_flit.range(23, 22) = is_bias ? "11" : "10";
    
    tx_fifo.push(header_flit);
    header_sent = true;
}

void Controller::create_data_flit(float data_val, bool is_last) {
    sc_lv<34> data_flit = 0;
    data_flit.range(33, 32) = is_last ? "01" : "00";
    data_flit.range(31, 0) = float_to_lv(data_val);
    
    tx_fifo.push(data_flit);
}

sc_lv<32> Controller::float_to_lv(float f) {
    sc_dt::scfx_ieee_float id(f);
    sc_lv<32> lv;
    
    lv[31] = id.negative() ? sc_dt::Log_1 : sc_dt::Log_0;
    lv.range(30, 23) = id.exponent();
    lv.range(22, 0) = id.mantissa();
    return lv;
}

float Controller::lv_to_float(sc_lv<32> lv) {
    sc_dt::scfx_ieee_float id;
    id.negative(lv[31].to_bool());
    id.exponent(lv.range(30, 23).to_uint());
    id.mantissa(lv.range(22, 0).to_uint());
    return float(id);
}

float Controller::lv32_to_float(sc_lv<32> lv) {
    union { uint32_t i; float f; } converter;
    converter.i = 0;
    
    // Convert sc_lv<32> to uint32_t
    for (int bit_idx = 0; bit_idx < 32; bit_idx++) {
        if (lv[bit_idx] == sc_dt::Log_1) {
            converter.i |= (1U << bit_idx);
        }
    }
    return converter.f;
}

void Controller::log_debug(const string& msg) {
    cout << "[CONTROLLER] " << msg << " (State: " << current_state << 
            ", Cycle: " << sc_time_stamp() << ")" << endl;
}

void Controller::print_top100_results() {
    if (fc8_results.size() != 1000) {
        log_debug("ERROR: Expected 1000 results, got " + int_to_string(fc8_results.size()));
        return;
    }
    
    vector<pair<double, int> > indexed_values;
    
    double exp_sum = 0.0;
    for (int i = 0; i < 1000; i++) {
        exp_sum += exp(static_cast<double>(fc8_results[i]));
    }
    
    for (int i = 0; i < 1000; i++) {
        double probability = exp(static_cast<double>(fc8_results[i])) / exp_sum;
        indexed_values.push_back(make_pair(probability, i));
    }
    
    sort(indexed_values.begin(), indexed_values.end(), compare_results);
    
    cout << fixed << setprecision(2);
    cout << "Top 100 classes:" << endl;
    cout << "=================================================" << endl;
    cout << right << setw(5) << "idx" << " | " 
         << setw(8) << "val" << " | " 
         << setw(11) << "possibility" << " | " 
         << "class name" << endl;
    cout << "-------------------------------------------------" << endl;
    
    for (int i = 0; i < 100; i++) {
        int class_idx = indexed_values[i].second;
        double probability_percent = indexed_values[i].first * 100.0;
        float original_logit = fc8_results[class_idx];
        
        cout << right << setw(5) << class_idx << " | " 
             << setw(8) << fixed << setprecision(2) << original_logit << " | " 
             << setw(11) << fixed << setprecision(2) << probability_percent << " | ";
        
        if (class_idx < class_names.size()) {
            cout << class_names[class_idx];
        } else {
            cout << "unknown_class";
        }
        cout << endl;
    }
    
    cout << "=================================================" << endl;
}

#endif