#include "pe.h"
#include <sstream>
#include <fstream>
#include <string>

#define get_cycle() int(sc_time_stamp().to_seconds() * 1e9 / 10)

PE::PE(){
    has_weights = false;
    has_bias = false;
    has_input = false;
    computation_done = false;
    input_height = input_width = input_channels = 0;
}

void PE::init(int pe_id)
{
    id = pe_id;
    cout << "[PE_" << id << "] Initialized for ";
    switch(id) {
        case 1: cout << "Conv1 + MaxPool1 (with input padding)"; break;
        case 2: cout << "Conv2 + MaxPool2"; break;
        case 3: cout << "Conv3"; break;
        case 4: cout << "FC7"; break;
        case 5: cout << "FC6"; break;
        case 6: cout << "Conv5 + MaxPool3"; break;
        case 7: cout << "Conv4"; break;
        case 12: cout << "FC8"; break;
        default: cout << "Unknown layer"; break;
    }
    cout << endl;
}

bool PE::is_ready_to_compute() {
    return has_weights && has_bias && has_input && !computation_done;
}

Packet* PE::get_packet()
{
    if (!computation_done || output_data_vec.empty()) {
        return NULL;
    }
    

    Packet* output_packet = new Packet();
    output_packet->source_id = id;
    output_packet->dest_id = get_next_pe_id();
    output_packet->packet_type = 3; // output data
    output_packet->datas = output_data_vec;
    

    get_output_dimensions(output_packet->height, output_packet->width, output_packet->channels);
    
    cout << "[PE_" << id << "] Sending output to PE_" << output_packet->dest_id 
         << ", size: " << output_data_vec.size() << endl;
    

    computation_done = false;
    has_input = false;
    output_data_vec.clear();
    
    return output_packet;
}

void PE::check_packet(Packet* p) {
    if (p->packet_type == 0) {  // Weight packet
        weights_vec.swap(p->datas);
        has_weights = true;
        cout << "[PE_" << id << "] Received weights, size: " << weights_vec.size() << endl;
        
    } else if (p->packet_type == 1) {  // Bias packet
        bias_vec.swap(p->datas);
        has_bias = true;
        cout << "[PE_" << id << "] Received bias, size: " << bias_vec.size() << endl;
        
    } else if (p->packet_type == 2 || p->packet_type == 3) {  // Input/Output data packet

        try {
        
            vector<float>().swap(input_data_vec);
        
            input_data_vec.swap(p->datas);
            
            cout << "[PE_" << id << "] Successfully swapped input data, size: " << input_data_vec.size() << endl;
        } catch (const std::exception& e) {
            cout << "[PE_" << id << "] ERROR: Exception during data swap: " << e.what() << endl;
            return;
        }
        
        if (p->packet_type == 2) {

            if (id == 1) {

                    input_height = 224;
                    input_width = 224;
                    input_channels = 3;
                    cout << "[PE_" << id << "] Received raw input: 224x224x3, will perform padding" << endl;

            } else {
                cout << "[PE_" << id << "] receive data size: " << input_data_vec.size() << endl;
                //return;
            }
        } else {
            input_height = p->height;
            input_width = p->width;
            input_channels = p->channels;
            cout << "[PE_" << id << "] Received output from previous PE: " 
                 << input_height << "x" << input_width << "x" << input_channels << endl;
                 
            int expected_size = input_height * input_width * input_channels;
            if (input_data_vec.size() != expected_size) {
                cout << "[PE_" << id << "] WARNING: Data size mismatch. Expected: " << expected_size 
                     << ", Got: " << input_data_vec.size() << endl;
            }
        }
        
        has_input = true;
        computation_done = false;
        
        cout << "[PE_" << id << "] Input data ready. Weights: " << (has_weights ? "✓" : "✗") 
             << ", Bias: " << (has_bias ? "✓" : "✗") << ", Input: " << (has_input ? "✓" : "✗") << endl;
        
        if (is_ready_to_compute()) {
            cout << "[PE_" << id << "] All data ready, starting computation..." << endl;
            perform_computation();
        } else {
            cout << "[PE_" << id << "] Not ready to compute yet." << endl;
        }
        
    } else {
        cout << "[PE_" << id << "] received unknown packet type: " << p->packet_type << endl;
    }
    

    if (p && !p->datas.empty()) {
        vector<float>().swap(p->datas);
    }
}

void PE::print_first_last_10(const vector<float>& data, const string& layer_name) {
    if (data.empty()) {
        cout << "[PE_" << id << "] " << layer_name << " output is empty!" << endl;
        return;
    }
    
    cout << "[PE_" << id << "] " << layer_name << " - First 10 elements:" << endl;
    int first_count = min(10, (int)data.size());
    for (int i = 0; i < first_count; i++) {
        cout << "[PE_" << id << "] " << layer_name << "_output[" << i << "] = " << data[i] << endl;
    }
    
    if (data.size() > 10) {
        cout << "[PE_" << id << "] " << layer_name << " - Last 10 elements:" << endl;
        int start_idx = max(0, (int)data.size() - 10);
        for (int i = start_idx; i < data.size(); i++) {
            cout << "[PE_" << id << "] " << layer_name << "_output[" << i << "] = " << data[i] << endl;
        }
    }
    cout << "========================================================" << endl;
}

void PE::perform_computation() {
    cout << "[PE_" << id << "] Starting computation..." << endl;
    
    switch(id) {
        case 1:
            compute_conv1_maxpool1();
            break;
        case 2:
            compute_conv2_maxpool2();
            break;
        case 3:
            compute_conv3();
            break;
        case 4:
            compute_fc7();
            break;
        case 5:
            compute_fc6();
            break;
        case 6:
            compute_conv5_maxpool3();
            break;
        case 7:
            compute_conv4();
            break;
        case 12:
            compute_fc8();
            break;
        default:
            cout << "[PE_" << id << "] Unknown PE ID!" << endl;
            return;
    }
    
    computation_done = true;
    cout << "[PE_" << id << "] Computation completed, output size: " << output_data_vec.size() << endl;
}

void PE::perform_input_padding() {
    const int orig_height = 224;
    const int orig_width = 224;
    const int channels = 3;
    const int pad_top = 2, pad_left = 2, pad_bottom = 1, pad_right = 1;
    const int padded_height = orig_height + pad_top + pad_bottom;  // 227
    const int padded_width = orig_width + pad_left + pad_right;    // 227
    
    cout << "[PE_" << id << "] Performing input padding: 224x224x3 -> 227x227x3" << endl;
    

    int expected_raw_size = orig_height * orig_width * channels;  // 150528
    if (input_data_vec.size() != expected_raw_size) {
        cout << "[PE_" << id << "] ERROR: Expected 150528 pixels, got " << input_data_vec.size() << endl;
        return;
    }
    

    vector<float> padded_data;
    int padded_size = padded_height * padded_width * channels;  // 154587
    padded_data.resize(padded_size, 0.0f);
    
 
    for (int c = 0; c < channels; c++) {
        for (int y = 0; y < orig_height; y++) {
            for (int x = 0; x < orig_width; x++) {
  
                int orig_idx = (c * orig_height * orig_width) + (y * orig_width) + x;
                                int padded_y = y + pad_top;
                int padded_x = x + pad_left;
                int padded_idx = (c * padded_height * padded_width) + 
                               (padded_y * padded_width) + padded_x;
                
                if (orig_idx < input_data_vec.size() && padded_idx < padded_data.size()) {
                    padded_data[padded_idx] = input_data_vec[orig_idx];
                }
            }
        }
    }
    
    input_data_vec = padded_data;
    input_height = 227;
    input_width = 227;
    input_channels = 3;
    
    // cout << "[PE_" << id << "] Padding completed: " << input_data_vec.size() << " pixels" << endl;
    // cout << "[PE_" << id << "] Sample padded values: [0]=" << input_data_vec[0] 
    //      << ", [1000]=" << input_data_vec[1000] 
    //      << ", [" << (input_data_vec.size()-1) << "]=" << input_data_vec[input_data_vec.size()-1] << endl;
}

void PE::compute_conv1_maxpool1() {
    if (input_height == 224 && input_width == 224 && input_channels == 3) {
        perform_input_padding();
    }
    
    if (input_height != 227 || input_width != 227 || input_channels != 3) {
        cout << "[PE_" << id << "] ERROR: Conv1 expects 227x227x3 input, got " 
             << input_height << "x" << input_width << "x" << input_channels << endl;
        return;
    }

    vector<float> conv_output;
    convolution_2d(input_data_vec, conv_output, 227, 227, 3, 64, 11, 4, 0, true);
    //print_first_last_10(conv_output, "conv1");
    
    // MaxPool1: 55x55->27x27, pool=3, stride=2
    maxpooling_2d(conv_output, output_data_vec, 55, 55, 64, 3, 2);
    //print_first_last_10(output_data_vec, "pool1");
    
   // cout << "[PE_" << id << "] Conv1+MaxPool1: 227x227x3 -> 27x27x64" << endl;
}

void PE::compute_conv2_maxpool2() {
    vector<float> conv_output;
    convolution_2d(input_data_vec, conv_output, 27, 27, 64, 192, 5, 1, 2, true);
    //print_first_last_10(conv_output, "conv2");
    
    // MaxPool2: 27x27->13x13, pool=3, stride=2
    maxpooling_2d(conv_output, output_data_vec, 27, 27, 192, 3, 2);
    //print_first_last_10(output_data_vec, "pool2");
    
    //cout << "[PE_" << id << "] Conv2+MaxPool2: 27x27x64 -> 13x13x192" << endl;
}

void PE::compute_conv3() {
    // Conv3: 192->384, 13x13->13x13, kernel=3, stride=1, padding=1 (使用ReLU)
    convolution_2d(input_data_vec, output_data_vec, 13, 13, 192, 384, 3, 1, 1, true);
    //print_first_last_10(output_data_vec, "conv3");
    
    //cout << "[PE_" << id << "] Conv3: 13x13x192 -> 13x13x384" << endl;
}

void PE::compute_conv4() {
    // Conv4: 384->256, 13x13->13x13, kernel=3, stride=1, padding=1 (使用ReLU)
    convolution_2d(input_data_vec, output_data_vec, 13, 13, 384, 256, 3, 1, 1, true);
    //print_first_last_10(output_data_vec, "conv4");
    
   // cout << "[PE_" << id << "] Conv4: 13x13x384 -> 13x13x256" << endl;
}

void PE::compute_conv5_maxpool3() {
    // Conv5: 256->256, 13x13->13x13, kernel=3, stride=1, padding=1 (使用ReLU)
    vector<float> conv_output;
    convolution_2d(input_data_vec, conv_output, 13, 13, 256, 256, 3, 1, 1, true);
   // print_first_last_10(conv_output, "conv5");
    
    // MaxPool3: 13x13->6x6, pool=3, stride=2
    maxpooling_2d(conv_output, output_data_vec, 13, 13, 256, 3, 2);
   // print_first_last_10(output_data_vec, "pool5");
    
   // cout << "[PE_" << id << "] Conv5+MaxPool3: 13x13x256 -> 6x6x256" << endl;
}

void PE::compute_fc6() {
    // FC6: 9216->4096 (使用ReLU)
    fully_connected(input_data_vec, output_data_vec, 9216, 4096, true);
    //print_first_last_10(output_data_vec, "fc6");
    
   // cout << "[PE_" << id << "] FC6: 9216 -> 4096" << endl;
}

void PE::compute_fc7() {
    // FC7: 4096->4096 (使用ReLU)
    fully_connected(input_data_vec, output_data_vec, 4096, 4096, true);
    //print_first_last_10(output_data_vec, "fc7");
    
    //cout << "[PE_" << id << "] FC7: 4096 -> 4096" << endl;
}

void PE::compute_fc8() {
    // FC8: 4096->1000 (不使用ReLU，用於分類)
    fully_connected(input_data_vec, output_data_vec, 4096, 1000, false);
    //print_first_last_10(output_data_vec, "fc8");
    
    //cout << "[PE_" << id << "] FC8: 4096 -> 1000" << endl;
}

void PE::convolution_2d(const vector<float>& input, vector<float>& output,
                       int in_h, int in_w, int in_ch, int out_ch,
                       int kernel_size, int stride, int padding, bool use_relu) {
    
    // cout << "[PE_" << id << "] Starting convolution: " << in_h << "x" << in_w << "x" << in_ch 
    //      << " -> " << out_ch << " channels, kernel=" << kernel_size << endl;
    // cout << "[PE_" << id << "] Input vector size: " << input.size() << ", Weights size: " << weights_vec.size() 
    //      << ", Bias size: " << bias_vec.size() << endl;
    
    int out_h = (in_h + 2 * padding - kernel_size) / stride + 1;
    int out_w = (in_w + 2 * padding - kernel_size) / stride + 1;
    
    // cout << "[PE_" << id << "] Output dimensions: " << out_h << "x" << out_w << "x" << out_ch 
    //      << " = " << (out_ch * out_h * out_w) << " elements" << endl;
    
    
    int expected_input_size = in_h * in_w * in_ch;
    if (input.size() != expected_input_size) {
        cout << "[PE_" << id << "] ERROR: Input size mismatch. Expected: " << expected_input_size 
             << ", Got: " << input.size() << endl;
        return;
    }
    

    int expected_weight_size = out_ch * in_ch * kernel_size * kernel_size;
    if (weights_vec.size() != expected_weight_size) {
        // cout << "[PE_" << id << "] ERROR: Weight size mismatch. Expected: " << expected_weight_size 
        //      << ", Got: " << weights_vec.size() << endl;
        return;
    }
    
    output.clear();
    output.resize(out_ch * out_h * out_w, 0.0);
    
    //cout << "[PE_" << id << "] Starting convolution loops..." << endl;
    
    for (int oc = 0; oc < out_ch; oc++) {
        // if (oc % 16 == 0) {  
        //     cout << "[PE_" << id << "] Processing output channel " << oc << "/" << out_ch << endl;
        // }
        
        for (int oh = 0; oh < out_h; oh++) {
            for (int ow = 0; ow < out_w; ow++) {
                float sum = 0.0;
                
                for (int ic = 0; ic < in_ch; ic++) {
                    for (int kh = 0; kh < kernel_size; kh++) {
                        for (int kw = 0; kw < kernel_size; kw++) {
                            int ih = oh * stride + kh - padding;
                            int iw = ow * stride + kw - padding;
                            
                            if (ih >= 0 && ih < in_h && iw >= 0 && iw < in_w) {
                                int input_idx = ic * in_h * in_w + ih * in_w + iw;
                                int weight_idx = oc * in_ch * kernel_size * kernel_size + 
                                               ic * kernel_size * kernel_size + kh * kernel_size + kw;
                                
                                
                                if (input_idx >= 0 && input_idx < input.size() && 
                                    weight_idx >= 0 && weight_idx < weights_vec.size()) {
                                    sum += input[input_idx] * weights_vec[weight_idx];
                                } else {
                                    cout << "[PE_" << id << "] WARNING: Index out of bounds. input_idx=" 
                                         << input_idx << ", weight_idx=" << weight_idx << endl;
                                }
                            }
                        }
                    }
                }
                
                if (oc < bias_vec.size()) {
                    sum += bias_vec[oc];
                }
                
                int output_idx = oc * out_h * out_w + oh * out_w + ow;
                if (output_idx >= 0 && output_idx < output.size()) {
                    output[output_idx] = use_relu ? max(0.0f, sum) : sum;
                } else {
                    cout << "[PE_" << id << "] ERROR: Output index out of bounds: " << output_idx << endl;
                    return;
                }
            }
        }
    }
    
   // cout << "[PE_" << id << "] Convolution completed successfully!" << endl;
}

void PE::maxpooling_2d(const vector<float>& input, vector<float>& output,
                      int in_h, int in_w, int in_ch, 
                      int pool_size, int pool_stride) {
    int out_h = (in_h - pool_size) / pool_stride + 1;
    int out_w = (in_w - pool_size) / pool_stride + 1;
    
    output.clear();
    output.resize(in_ch * out_h * out_w, 0.0);
    
    for (int c = 0; c < in_ch; c++) {
        for (int oh = 0; oh < out_h; oh++) {
            for (int ow = 0; ow < out_w; ow++) {
                float max_val = -1e30;
                
                for (int ph = 0; ph < pool_size; ph++) {
                    for (int pw = 0; pw < pool_size; pw++) {
                        int ih = oh * pool_stride + ph;
                        int iw = ow * pool_stride + pw;
                        
                        if (ih < in_h && iw < in_w) {
                            int input_idx = c * in_h * in_w + ih * in_w + iw;
                            if (input_idx < input.size()) {
                                max_val = max(max_val, input[input_idx]);
                            }
                        }
                    }
                }
                
                int output_idx = c * out_h * out_w + oh * out_w + ow;
                output[output_idx] = max_val;
            }
        }
    }
}

void PE::fully_connected(const vector<float>& input, vector<float>& output,
                        int input_size, int output_size, bool use_relu) {
    output.clear();
    output.resize(output_size, 0.0);
    
    for (int o = 0; o < output_size; o++) {
        float sum = 0.0;
        
        for (int i = 0; i < input_size; i++) {
            int weight_idx = o * input_size + i;
            if (i < input.size() && weight_idx < weights_vec.size()) {
                sum += input[i] * weights_vec[weight_idx];
            }
        }
        

        if (o < bias_vec.size()) {
            sum += bias_vec[o];
        }
        
        output[o] = use_relu ? max(0.0f, sum) : sum;
    }
}

int PE::get_next_pe_id() {
    switch(id) {
        case 1: return 2;   // Conv1+MaxPool1 -> Conv2+MaxPool2
        case 2: return 3;   // Conv2+MaxPool2 -> Conv3
        case 3: return 7;   // Conv3 -> Conv4
        case 7: return 6;   // Conv4 -> Conv5+MaxPool3
        case 6: return 5;   // Conv5+MaxPool3 -> FC6
        case 5: return 4;   // FC6 -> FC7
        case 4: return 12;  // FC7 -> FC8
        case 12: return 0;  // FC8 -> Controller (結果回傳)
        default: return 0;
    }
}

void PE::get_output_dimensions(int& out_h, int& out_w, int& out_ch) {
    switch(id) {
        case 1:  out_h = 27; out_w = 27; out_ch = 64; break;   // Conv1+MaxPool1
        case 2:  out_h = 13; out_w = 13; out_ch = 192; break;  // Conv2+MaxPool2
        case 3:  out_h = 13; out_w = 13; out_ch = 384; break;  // Conv3
        case 7:  out_h = 13; out_w = 13; out_ch = 256; break;  // Conv4
        case 6:  out_h = 6;  out_w = 6;  out_ch = 256; break;  // Conv5+MaxPool3
        case 5:  out_h = 1;  out_w = 4096; out_ch = 1; break;  // FC6
        case 4:  out_h = 1;  out_w = 4096; out_ch = 1; break;  // FC7
        case 12: out_h = 1;  out_w = 1000; out_ch = 1; break;  // FC8
        default: out_h = 1; out_w = 1; out_ch = 1; break;
    }
}