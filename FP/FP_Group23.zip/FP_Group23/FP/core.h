#ifndef CORE_H
#define CORE_H

#include "systemc.h"
#include "pe.h"
#include <queue>
#include <vector>

SC_MODULE(Core) {
    enum SendState { SEND_IDLE, SENDING };
    enum RecvState { RECV_IDLE, RECV_HEADER_WAIT, RECV_BODY };
    enum PacketType {  
        WEIGHT_PACKET = 0,    
        BIAS_PACKET = 1,
        INPUT_PACKET = 2,  
        OUTPUT_PACKET = 3
    };
    sc_in<bool> rst;
    sc_in<bool> clk;

    // receive from router
    sc_in<sc_lv<34> > flit_rx;
    sc_in<bool> req_rx;
    sc_out<bool> ack_rx;
    
    // transmit to router
    sc_out<sc_lv<34> > flit_tx;
    sc_out<bool> req_tx;
    sc_in<bool> ack_tx;

    PE pe;
    int pe_id;

    std::queue<sc_lv<34> > output_queue;
    Packet* packet_from_pe;

    Packet* packet_to_pe;
    sc_lv<34> flit_rx_temp;

    SendState send_state;
    RecvState recv_state;
    bool ready_to_send_conv_output;
    void run();
    void reset();
    void fsm_send();
    void fsm_recv();

    SC_HAS_PROCESS(Core);
    Core(sc_module_name name, int core_id) : pe_id(core_id), pe() {
        pe.init(pe_id);
        packet_from_pe = NULL;
        packet_to_pe = NULL;
        send_state = SEND_IDLE;
        recv_state = RECV_IDLE;
        SC_METHOD(run);
        sensitive << clk.pos();
        dont_initialize();
    }

    sc_lv<32> Float_to_LV(float f);
    float LV_to_Float(sc_lv<32> lv);
};

void Core::reset() {
    send_state = SEND_IDLE;
    recv_state = RECV_IDLE;
    ready_to_send_conv_output = 0;
    while (!output_queue.empty()) output_queue.pop();
    if (packet_to_pe) delete packet_to_pe;
    packet_to_pe = NULL;
    req_tx.write(0);
    ack_rx.write(0);
    flit_tx.write(0);
}

sc_lv<32> Core::Float_to_LV(float f) {
    sc_dt::scfx_ieee_float ieee(f);
    sc_lv<32> lv;
    lv[31] = ieee.negative() ? '1' : '0';
    lv.range(30, 23) = ieee.exponent();
    lv.range(22, 0) = ieee.mantissa();
    return lv;
}

float Core::LV_to_Float(sc_lv<32> lv) {
    sc_dt::scfx_ieee_float ieee;
    ieee.negative(lv[31] == '1');
    ieee.exponent(lv.range(30, 23).to_uint());
    ieee.mantissa(lv.range(22, 0).to_uint());
    return float(ieee);
}

void Core::fsm_send() {
    switch (send_state) {
        case SEND_IDLE:
            if (output_queue.empty()) {
                packet_from_pe = pe.get_packet();
                if (packet_from_pe) {
                    cout << "Core_" << pe_id << " ready to send conv output" << endl;
                    cout << "Core_" << pe_id << " packet_from_pe data size: " << packet_from_pe->datas.size() << endl;
                    
                    // 檢查數據大小是否合理
                    if (packet_from_pe->datas.empty()) {
                        cout << "[Core_" << pe_id << "] ERROR: Empty data packet!" << endl;
                        delete packet_from_pe;
                        packet_from_pe = NULL;
                        return;
                    }
                    
                    // 清空輸出隊列（雖然應該已經是空的）
                    while (!output_queue.empty()) output_queue.pop();
                    
                    // build header
                    sc_lv<34> hf;
                    hf.range(33, 32) = "10";  // BOP (Beginning of Packet)
                    hf.range(31, 28) = packet_from_pe->source_id;
                    hf.range(27, 24) = packet_from_pe->dest_id;
                    hf.range(23, 22) = "00";  // Data packet type
                    hf.range(21, 0) = 0;      // 修正：不要覆蓋 bits 23-22
                    output_queue.push(hf);
                    
                    // build body and tail
                    for (size_t i = 0; i < packet_from_pe->datas.size(); ++i) {
                        sc_lv<34> df;
                        bool is_last = (i == (packet_from_pe->datas.size()-1));
                        df.range(33, 32) = is_last ? "01" : "00";  // EOP if last
                        df.range(31, 0) = Float_to_LV(packet_from_pe->datas[i]);
                        output_queue.push(df);
                    }
                    
                    // 安全的數據檢查輸出
                    if (packet_from_pe->datas.size() >= 4) {
                        size_t size = packet_from_pe->datas.size();
                         cout << "Core_" << pe_id << " First data values: " 
                             << packet_from_pe->datas[0] << endl;
                        cout << "Core_" << pe_id << " last 4 data values: " 
                             << packet_from_pe->datas[size-4] << " "
                             << packet_from_pe->datas[size-3] << " "
                             << packet_from_pe->datas[size-2] << " "
                             << packet_from_pe->datas[size-1] << endl;
                    }
                    
                    cout << "Core_" << pe_id << " output queue size: " << output_queue.size() << endl;
                    
                    send_state = SENDING;
                    req_tx.write(1);
                    flit_tx.write(output_queue.front());
                    
                    cout << "Core_" << pe_id << " send BOP flit: " << output_queue.front() 
                         << " dest: " << packet_from_pe->dest_id 
                         << " src: " << packet_from_pe->source_id << endl;
                         
                } else {
                    req_tx.write(0);
                    flit_tx.write(0);
                }
            }
            break;
            
        case SENDING:
            if (req_tx.read() && ack_tx.read()) {
                if (!output_queue.empty()) {
                    output_queue.pop();
                    
                    if (!output_queue.empty()) {
                        // 還有更多數據要發送
                        req_tx.write(1);
                        flit_tx.write(output_queue.front());
                        //cout << "Core_" << pe_id << " send flit: " << output_queue.front() << endl;
                    } else {
                        // 所有數據發送完畢
                        send_state = SEND_IDLE;
                        req_tx.write(0);
                        flit_tx.write(0);
                        
                        cout << "Core_" << pe_id << " send state back to SEND_IDLE" << endl;
                        cout << "Core_" << pe_id << " packet transmission completed" << endl;
                        
                        // 清理 packet_from_pe
                        if (packet_from_pe) {
                            delete packet_from_pe;
                            packet_from_pe = NULL;
                        }
                    }
                } else {
                    // 意外的空隊列情況
                    cout << "[Core_" << pe_id << "] ERROR: output_queue is empty in SENDING state!" << endl;
                    send_state = SEND_IDLE;
                    req_tx.write(0);
                    flit_tx.write(0);
                    
                    // 清理
                    if (packet_from_pe) {
                        delete packet_from_pe;
                        packet_from_pe = NULL;
                    }
                }
            } else if (req_tx.read()) {
                // 等待 ACK，保持當前 flit
                if (!output_queue.empty()) {
                    flit_tx.write(output_queue.front());
                } else {
                    cout << "[Core_" << pe_id << "] ERROR: output_queue empty while waiting for ACK!" << endl;
                    send_state = SEND_IDLE;
                    req_tx.write(0);
                    flit_tx.write(0);
                }
            }
            break;
    }
}

void Core::fsm_recv() {
    switch (recv_state) {
        case RECV_IDLE:
            if (req_rx.read()) {
                flit_rx_temp = flit_rx.read();
                
                // header flit?
                if ((flit_rx_temp.range(33,32) == "10")) {
                    if (packet_to_pe) delete packet_to_pe;
                    packet_to_pe = new Packet();
                    packet_to_pe->source_id = flit_rx_temp.range(31,28).to_uint();
                    packet_to_pe->dest_id   = flit_rx_temp.range(27,24).to_uint();
                    sc_lv<2> packet_type_bits = flit_rx_temp.range(23,22);

                    if (packet_type_bits == "00") {
                        packet_to_pe->packet_type = INPUT_PACKET;
                        cout << "Core_" << pe_id << " received DATA packet" <<  endl;
                    } else if (packet_type_bits == "10") {
                        packet_to_pe->packet_type = WEIGHT_PACKET;
                        cout << "Core_" << pe_id << " received WEIGHT packet" <<  endl;
                    } else if (packet_type_bits == "11") {
                        packet_to_pe->packet_type = BIAS_PACKET;
                        cout << "Core_" << pe_id << " received BIAS packet" <<  endl;
                    } else {
                        cout << "Core_" << pe_id << " received unknown packet type: " << packet_type_bits << endl;
                        exit(1);
                    }

                    // Commented out debug prints
                     cout << "Core_" << pe_id << " received header flit: " << flit_rx_temp << " dest id: " << packet_to_pe->dest_id << " src id: " << packet_to_pe->source_id << endl;
                    if (packet_to_pe->dest_id != pe_id) {
                        cout << "Core_" << pe_id << " received packet for another PE: " << packet_to_pe->dest_id << endl;
                        cout << "MISMATCH" << endl;
                        exit(1);
                    }
                    packet_to_pe->datas.clear();
                    ack_rx.write(1);
                    recv_state = RECV_BODY;
                } else {
                    ack_rx.write(0);
                }
            } else {
                ack_rx.write(0);
            }
            break;
        case RECV_BODY:
            if (req_rx.read()) {
                flit_rx_temp = flit_rx.read();
                sc_lv<2> type = flit_rx_temp.range(33,32);
                // cout << "Core_" << pe_id << " received flit: " << flit_rx_temp << endl;
                // cout << "Dest id " << packet_to_pe->dest_id << endl;
                float da = LV_to_Float(flit_rx_temp.range(31,0));
                // cout << "Core_" << pe_id << " received data: " << da << endl;
                if (type == "00" ) {
                    float val = LV_to_Float(flit_rx_temp.range(31,0));
                    packet_to_pe->datas.push_back(val);
                    // if (pe_id ==  2)
                    // {
                    //     cout << "[Core_" << pe_id << "] data size: " << packet_to_pe->datas.size() << endl;
                    // }
            
                }
                else if (type == "01") {
                    packet_to_pe->datas.push_back(da);
                    cout << "[Core_" << pe_id << "] received flit: " << flit_rx_temp << endl;
                    cout << "[Core_" << pe_id << "] received data: " << da << endl;
                    if(pe_id == packet_to_pe->dest_id ) {

                        pe.check_packet(packet_to_pe);
                        if (packet_to_pe->packet_type == INPUT_PACKET){
                            cout << "==========================================" << endl;
                            cout << "Core_" << pe_id << " CALC complete" << endl;
                            cout << "==========================================" << endl;
                            ready_to_send_conv_output = true;
                        } else {
                            cout << "==========================================" << endl;
                            cout << "Core_" << pe_id << " CHECK pass" << endl;
                            cout << "==========================================" << endl;                            
                        }

                        
                    }
                    packet_to_pe = NULL;
                    recv_state = RECV_IDLE;
                }
                ack_rx.write(1);
            } else {
                ack_rx.write(0);
            }
            break;
        default: recv_state = RECV_IDLE; break;
    }
}

void Core::run() {
    if (rst.read()) { reset(); return; }
    fsm_send();
    fsm_recv();
}

#endif
