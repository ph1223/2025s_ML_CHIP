#include "systemc.h"
#include "clockreset.h"
#include "DMA_controller.h"  // Updated controller with AXI interface
#include "dram.h"           // New DRAM module instead of ROM
#include "core.h"
#include "router.h"
#include <iostream>

int sc_main(int argc, char* argv[])
{
    // =======================
    //   signals declaration
    // =======================
    sc_signal < bool > clk;
    sc_signal < bool > rst;

    // AXI Read Address Channel (Controller -> DRAM)
    sc_signal<sc_lv<32> >   araddr;     
    sc_signal<sc_lv<8> >    arlen;      
    sc_signal<sc_lv<3> >    arsize;     
    sc_signal<sc_lv<2> >    arburst;    
    sc_signal<bool>        arvalid;    
    sc_signal<bool>        arready;    
    
    // AXI Read Data Channel (DRAM -> Controller)  
    sc_signal<sc_lv<32> >   rdata;      
    sc_signal<sc_lv<2> >    rresp;      
    sc_signal<bool>        rlast;      
    sc_signal<bool>        rvalid;     
    sc_signal<bool>        rready;

    // =======================
    // Router signals (unchanged)
    // =======================

    // inter-router / router–core handshaking buses
    sc_signal<sc_lv<34> >      in_flit[16][5];
    sc_signal<bool>           in_req [16][5];
    sc_signal<bool>           in_ack [16][5];

    sc_signal<sc_lv<34> >      flit_rx[16];
    sc_signal<bool>           req_rx [16];
    sc_signal<bool>           ack_rx [16];

    sc_signal<sc_lv<34> >      flit_tx[16];
    sc_signal<bool>           req_tx [16];
    sc_signal<bool>           ack_tx [16];

    // dummy signals for "no neighbor" in mesh, one per router per direction
    // directions: 0=left, 1=right, 2=up, 3=down
    sc_signal<sc_lv<34> >      empty_flit[16][4];
    sc_signal<bool>           empty_req [16][4];
    sc_signal<bool>           empty_ack [16][4];

    // =======================
    //   modules declaration
    // =======================
    Clock m_clock("m_clock", 10);
    Reset m_reset("m_reset", 15);
    Controller m_controller("m_controller");  // AXI-enabled controller
    DRAM m_dram("m_dram");                   // DRAM instead of ROM

    Core*   core_ptr  [15];
    Router* router_ptr[16];
    
    for (int i = 0; i < 16; i++) {
        router_ptr[i] = new Router(sc_gen_unique_name("m_Router"), i);
    }

    for (int i = 0; i < 15; i++) {
        core_ptr[i] = new Core(sc_gen_unique_name("m_Core"), i+1);
    }

    // =======================
    //   modules connection
    // =======================
    m_clock( clk );
    m_reset( rst );

    // DRAM connections
    m_dram.clk(clk);
    m_dram.rst(rst);
    
    // AXI Read Address Channel
    m_dram.araddr(araddr);
    m_dram.arlen(arlen);
    m_dram.arsize(arsize);
    m_dram.arburst(arburst);
    m_dram.arvalid(arvalid);
    m_dram.arready(arready);
    
    // AXI Read Data Channel
    m_dram.rdata(rdata);
    m_dram.rresp(rresp);
    m_dram.rlast(rlast);
    m_dram.rvalid(rvalid);
    m_dram.rready(rready);
    
    // Controller connections
    m_controller.clk(clk);
    m_controller.rst(rst);
    
    // Controller <-> DRAM (AXI interface)
    // AXI Read Address Channel
    m_controller.araddr(araddr);
    m_controller.arlen(arlen);
    m_controller.arsize(arsize);
    m_controller.arburst(arburst);
    m_controller.arvalid(arvalid);
    m_controller.arready(arready);
    
    // AXI Read Data Channel
    m_controller.rdata(rdata);
    m_controller.rresp(rresp);
    m_controller.rlast(rlast);
    m_controller.rvalid(rvalid);
    m_controller.rready(rready);
    
    // Controller <-> Router (unchanged)
    m_controller.flit_tx(flit_tx[0]);
    m_controller.req_tx(req_tx[0]);
    m_controller.ack_tx(ack_tx[0]);
    m_controller.flit_rx(flit_rx[0]);
    m_controller.req_rx(req_rx[0]);
    m_controller.ack_rx(ack_rx[0]);

    // Core connections (unchanged)
    for (int i = 0; i < 15; i++) {
        core_ptr[i]->clk(   clk);
        core_ptr[i]->rst(   rst);
        core_ptr[i]->flit_rx(flit_rx[i+1]);
        core_ptr[i]->req_rx (req_rx[i+1]);
        core_ptr[i]->ack_rx (ack_rx[i+1]);
        core_ptr[i]->flit_tx(flit_tx[i+1]);
        core_ptr[i]->req_tx (req_tx[i+1]);
        core_ptr[i]->ack_tx (ack_tx[i+1]);
    }

    // Router connections in 4×4 mesh (unchanged)
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            int idx     = i*4 + j;
            bool hasL   = (j > 0);
            bool hasR   = (j < 3);
            bool hasU   = (i > 0);
            bool hasD   = (i < 3);

            router_ptr[idx]->clk(clk);
            router_ptr[idx]->rst(rst);

            // ── OUT ports (router → neighbor/core)
            // port 0: left
            if (hasL) {
                int L = idx - 1;
                router_ptr[idx]->out_flit[0]( in_flit[L][1] );
                router_ptr[idx]->out_req [0]( in_req[L][1] );
                router_ptr[idx]->out_ack [0]( in_ack[L][1] );
            } else {
                router_ptr[idx]->out_flit[0]( empty_flit[idx][0] );
                router_ptr[idx]->out_req [0]( empty_req [idx][0] );
                router_ptr[idx]->out_ack [0]( empty_ack[idx][0] );
            }

            // port 1: right
            if (hasR) {
                int R = idx + 1;
                router_ptr[idx]->out_flit[1]( in_flit[R][0] );
                router_ptr[idx]->out_req [1]( in_req[R][0] );
                router_ptr[idx]->out_ack [1]( in_ack[R][0] );
            } else {
                router_ptr[idx]->out_flit[1]( empty_flit[idx][1] );
                router_ptr[idx]->out_req [1]( empty_req [idx][1] );
                router_ptr[idx]->out_ack [1]( empty_ack[idx][1] );
            }

            // port 2: up
            if (hasU) {
                int U = (i-1)*4 + j;
                router_ptr[idx]->out_flit[2]( in_flit[U][3] );
                router_ptr[idx]->out_req [2]( in_req[U][3] );
                router_ptr[idx]->out_ack [2]( in_ack[U][3] );
            } else {
                router_ptr[idx]->out_flit[2]( empty_flit[idx][2] );
                router_ptr[idx]->out_req [2]( empty_req [idx][2] );
                router_ptr[idx]->out_ack [2]( empty_ack[idx][2] );
            }

            // port 3: down
            if (hasD) {
                int D = (i+1)*4 + j;
                router_ptr[idx]->out_flit[3]( in_flit[D][2] );
                router_ptr[idx]->out_req [3]( in_req[D][2] );
                router_ptr[idx]->out_ack [3]( in_ack[D][2] );
            } else {
                router_ptr[idx]->out_flit[3]( empty_flit[idx][3] );
                router_ptr[idx]->out_req [3]( empty_req [idx][3] );
                router_ptr[idx]->out_ack [3]( empty_ack[idx][3] );
            }

            // port 4: to/from local Core
            router_ptr[idx]->out_flit[4]( flit_rx[idx] );
            router_ptr[idx]->out_req [4]( req_rx [idx] );
            router_ptr[idx]->out_ack [4]( ack_tx [idx] );

            // ── IN ports (neighbor/core → router)
            for (int p = 0; p < 4; p++) {
                router_ptr[idx]->in_flit[p]( in_flit[idx][p] );
                router_ptr[idx]->in_req [p]( in_req [idx][p] );
                router_ptr[idx]->in_ack [p]( in_ack [idx][p] );
            }
            router_ptr[idx]->in_flit[4]( flit_tx[idx] );
            router_ptr[idx]->in_req [4] ( req_tx [idx] );
            router_ptr[idx]->in_ack[4]( ack_rx [idx] );
        }
    }

    // Initialize dummy signals to prevent floating
    for (int i = 0; i < 16; i++) {
        for (int j = 0; j < 4; j++) {
            empty_flit[i][j].write("0000000000000000000000000000000000");
            empty_req[i][j].write(false);
            empty_ack[i][j].write(false);
        }
    }


    sc_start(4000000, SC_MS);

    cout << "==================================================" << endl;
    cout << "Simulation completed successfully" << endl;
    cout << "==================================================" << endl;

    // Cleanup
    for (int i = 0; i < 15; i++) {
        delete core_ptr  [i];
        delete router_ptr[i];
    }
    delete router_ptr[15];
    
    return 0;
}